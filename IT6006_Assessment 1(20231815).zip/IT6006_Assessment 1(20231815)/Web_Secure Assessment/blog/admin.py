from django.contrib import admin
from .models import Tour, Agent
# Register your models here.
admin.site.register(Tour)
admin.site.register(Agent)