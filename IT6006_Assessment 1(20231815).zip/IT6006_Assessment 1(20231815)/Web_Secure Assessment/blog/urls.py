# myapp/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.HomePageView.as_view(), name='home'),
    path('tours/', views.TourListView.as_view(), name='tour_list'),
    path('tours/<int:pk>/', views.TourDetailView.as_view(), name='tour_detail'),
    path('agents/', views.AgentListView.as_view(), name='agent_list'),
    path('agents/<int:pk>/', views.AgentDetailView.as_view(), name='agent_detail'),
]
