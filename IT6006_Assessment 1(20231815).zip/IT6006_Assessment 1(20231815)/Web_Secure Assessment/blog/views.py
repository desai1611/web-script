from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView, DetailView, TemplateView
from .models import Tour, Agent
from django.shortcuts import render

class HomePageView(TemplateView):
    template_name = 'blog/home.html'

class TourListView(LoginRequiredMixin, ListView):
    model = Tour
    template_name = 'blog/tour_list.html'
    context_object_name = 'tours'
    login_url = '/account/login/'  # or your login URL

class TourDetailView(LoginRequiredMixin, DetailView):
    model = Tour
    template_name = 'blog/tour_detail.html'
    context_object_name = 'tour'
    login_url = '/account/login/'  # or your login URL

class AgentListView(LoginRequiredMixin, ListView):
    model = Agent
    template_name = 'blog/agent_list.html'
    context_object_name = 'agents'
    login_url = '/account/login/'  # or your login URL

class AgentDetailView(LoginRequiredMixin, DetailView):
    model = Agent
    template_name = 'blog/agent_detail.html'
    context_object_name = 'agent'
    login_url = '/account/login/'  # or your login URL
